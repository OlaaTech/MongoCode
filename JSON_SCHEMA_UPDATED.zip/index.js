const schema = require("./dataset.schema.json");
const { validate } = require("jsonschema");
const mongoose = require("mongoose");
require("dotenv").config();

async function connectMongo() {
  try {
    await mongoose.connect(
      `${process.env.MONGO_ADDRESS}/${process.env.MONGO_DB}`,
      {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      }
    );
    console.log("Mongo Connected");
  } catch (err) {
    console.log("Coulnt connect mongodb");
  }
}

async function main() {
  await connectMongo();
  await validateData();
  mongoose.disconnect();
}

async function validateData() {
  // this collection is the datasetv2 collection
  const DatasetModel = mongoose.model(
    process.env.MONGO_COLLECTION,
    new mongoose.Schema({}, { strict: false }),
    process.env.MONGO_COLLECTION
  );

  // this model will store the error messages for the validated records
  const InvalidModel = mongoose.model(
    process.env.MONGO_INVALID_COLLECTION,
    new mongoose.Schema({}, { strict: false }),
    process.env.MONGO_INVALID_COLLECTION
  );

  //   getting all the documents from mongodb
  let documents = await DatasetModel.find({}, { datasetv2: 1 });

  console.log(
    "Applying validations and storing in the mongo db collection",
    process.env.MONGO_INVALID_COLLECTION
  );
  console.log("This may take some time");

  for (let i = 0; i < documents.length; i++) {
    console.log(i + 1, "/", documents.length);
    const d = documents[i];
    if (d.datasetv2) {
      // validating each document with the JSON schema
      result = validate(d.datasetv2, schema);
      if (!result.valid) {
        const res = result.errors.map((r) => ({
          name: r.property.replace("instance.", ""),
          message: r.message,
          path: r.path,
        }));

        const doc = { docId: d._id.toString(), invalidProperties: res };

        const invalidDoc = new InvalidModel(doc);
        // storing the error messages into the invalid record's scehma
        await invalidDoc.save();
      }
    } else {
      // runs if the document doesnt contain datasetv2 property
      const doc = {
        docId: d._id.toString(),
        invalidProperties: "datasetv2 not found",
      };
      const invalidDoc = new InvalidModel(doc);
      await invalidDoc.save();
    }
  }

  console.log("Data has been validated");
}

main();
